
import { defineConfig } from "drizzle-kit";

if (!process.env.SQL_SERVER_HOST) {
  console.warn("SQL_SERVER_HOST not set. Please configure SQL Server connection.");
  process.exit(1);
}

export default defineConfig({
  out: "./migrations",
  schema: "./shared/schema.ts",
  dialect: "mssql",
  dbCredentials: {
    server: process.env.SQL_SERVER_HOST!,
    port: parseInt(process.env.SQL_SERVER_PORT || '1433'),
    database: process.env.SQL_SERVER_DATABASE!,
    user: process.env.SQL_SERVER_USER!,
    password: process.env.SQL_SERVER_PASSWORD!,
    options: {
      encrypt: process.env.SQL_SERVER_ENCRYPT === 'true',
      trustServerCertificate: process.env.SQL_SERVER_TRUST_CERT === 'true',
    }
  },
  verbose: true,
  strict: true,
});
