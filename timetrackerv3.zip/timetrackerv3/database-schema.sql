
-- TimeTracker Pro - SQL Server Database Schema
-- Create database and tables for time tracking application

-- Create the database (run separately if needed)
-- CREATE DATABASE timetracker;
-- USE timetracker;

-- Drop existing tables if they exist (in reverse dependency order)
IF OBJECT_ID('project_employees', 'U') IS NOT NULL DROP TABLE project_employees;
IF OBJECT_ID('time_entries', 'U') IS NOT NULL DROP TABLE time_entries;
IF OBJECT_ID('tasks', 'U') IS NOT NULL DROP TABLE tasks;
IF OBJECT_ID('projects', 'U') IS NOT NULL DROP TABLE projects;
IF OBJECT_ID('departments', 'U') IS NOT NULL DROP TABLE departments;
IF OBJECT_ID('organizations', 'U') IS NOT NULL DROP TABLE organizations;
IF OBJECT_ID('employees', 'U') IS NOT NULL DROP TABLE employees;
IF OBJECT_ID('users', 'U') IS NOT NULL DROP TABLE users;
IF OBJECT_ID('sessions', 'U') IS NOT NULL DROP TABLE sessions;

-- Sessions table for authentication
CREATE TABLE sessions (
    sid NVARCHAR(255) PRIMARY KEY,
    sess NVARCHAR(MAX) NOT NULL,
    expire DATETIME2 NOT NULL
);

-- Create index on expire column
CREATE INDEX IDX_session_expire ON sessions(expire);

-- Users table
CREATE TABLE users (
    id NVARCHAR(255) PRIMARY KEY DEFAULT NEWID(),
    email NVARCHAR(255) UNIQUE,
    first_name NVARCHAR(255),
    last_name NVARCHAR(255),
    profile_image_url NVARCHAR(500),
    role NVARCHAR(50) DEFAULT 'employee',
    is_active BIT DEFAULT 1,
    last_login_at DATETIME2,
    created_at DATETIME2 DEFAULT GETDATE(),
    updated_at DATETIME2 DEFAULT GETDATE()
);

-- Organizations table
CREATE TABLE organizations (
    id NVARCHAR(255) PRIMARY KEY DEFAULT NEWID(),
    name NVARCHAR(255) NOT NULL,
    description NTEXT,
    user_id NVARCHAR(255) NOT NULL,
    created_at DATETIME2 DEFAULT GETDATE(),
    updated_at DATETIME2 DEFAULT GETDATE(),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Employees table
CREATE TABLE employees (
    id NVARCHAR(255) PRIMARY KEY DEFAULT NEWID(),
    employee_id NVARCHAR(255) NOT NULL UNIQUE,
    first_name NVARCHAR(255) NOT NULL,
    last_name NVARCHAR(255) NOT NULL,
    department NVARCHAR(255) NOT NULL,
    user_id NVARCHAR(255) NOT NULL,
    created_at DATETIME2 DEFAULT GETDATE(),
    updated_at DATETIME2 DEFAULT GETDATE(),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Departments table
CREATE TABLE departments (
    id NVARCHAR(255) PRIMARY KEY DEFAULT NEWID(),
    name NVARCHAR(255) NOT NULL,
    organization_id NVARCHAR(255) NOT NULL,
    manager_id NVARCHAR(255),
    description NVARCHAR(500),
    user_id NVARCHAR(255) NOT NULL,
    created_at DATETIME2 DEFAULT GETDATE(),
    updated_at DATETIME2 DEFAULT GETDATE(),
    FOREIGN KEY (organization_id) REFERENCES organizations(id) ON DELETE CASCADE,
    FOREIGN KEY (manager_id) REFERENCES employees(id),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE NO ACTION
);

-- Projects table
CREATE TABLE projects (
    id NVARCHAR(255) PRIMARY KEY DEFAULT NEWID(),
    name NVARCHAR(255) NOT NULL,
    project_number NVARCHAR(50),
    description NTEXT,
    color NVARCHAR(7) DEFAULT '#1976D2',
    start_date DATETIME2,
    end_date DATETIME2,
    is_enterprise_wide BIT DEFAULT 1 NOT NULL,
    user_id NVARCHAR(255) NOT NULL,
    created_at DATETIME2 DEFAULT GETDATE(),
    updated_at DATETIME2 DEFAULT GETDATE(),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Tasks table
CREATE TABLE tasks (
    id NVARCHAR(255) PRIMARY KEY DEFAULT NEWID(),
    project_id NVARCHAR(255) NOT NULL,
    name NVARCHAR(255) NOT NULL,
    description NTEXT,
    status NVARCHAR(50) NOT NULL DEFAULT 'active',
    created_at DATETIME2 DEFAULT GETDATE(),
    updated_at DATETIME2 DEFAULT GETDATE(),
    FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE
);

-- Time entries table
CREATE TABLE time_entries (
    id NVARCHAR(255) PRIMARY KEY DEFAULT NEWID(),
    user_id NVARCHAR(255) NOT NULL,
    project_id NVARCHAR(255) NOT NULL,
    task_id NVARCHAR(255),
    description NTEXT,
    date DATE NOT NULL,
    start_time NVARCHAR(5) NOT NULL,
    end_time NVARCHAR(5) NOT NULL,
    duration DECIMAL(5,2) NOT NULL,
    created_at DATETIME2 DEFAULT GETDATE(),
    updated_at DATETIME2 DEFAULT GETDATE(),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE,
    FOREIGN KEY (task_id) REFERENCES tasks(id) ON DELETE SET NULL
);

-- Project employees table
CREATE TABLE project_employees (
    id NVARCHAR(255) PRIMARY KEY DEFAULT NEWID(),
    project_id NVARCHAR(255) NOT NULL,
    employee_id NVARCHAR(255) NOT NULL,
    user_id NVARCHAR(255) NOT NULL,
    created_at DATETIME2 DEFAULT GETDATE(),
    FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE,
    FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE NO ACTION
);

-- Create indexes for better performance
CREATE INDEX IX_users_email ON users(email);
CREATE INDEX IX_users_role ON users(role);
CREATE INDEX IX_time_entries_user_id ON time_entries(user_id);
CREATE INDEX IX_time_entries_date ON time_entries(date);
CREATE INDEX IX_time_entries_project_id ON time_entries(project_id);
CREATE INDEX IX_tasks_project_id ON tasks(project_id);
CREATE INDEX IX_employees_user_id ON employees(user_id);
CREATE INDEX IX_project_employees_project_id ON project_employees(project_id);
CREATE INDEX IX_project_employees_employee_id ON project_employees(employee_id);

-- Insert default admin user (optional)
-- INSERT INTO users (id, email, first_name, last_name, role, is_active) 
-- VALUES (NEWID(), 'admin@timetracker.com', 'System', 'Administrator', 'admin', 1);

-- Insert sample organization (optional)
-- INSERT INTO organizations (id, name, description, user_id)
-- VALUES (NEWID(), 'Default Organization', 'Default organization for time tracking', 
--         (SELECT TOP 1 id FROM users WHERE role = 'admin'));

PRINT 'TimeTracker Pro database schema created successfully!';
