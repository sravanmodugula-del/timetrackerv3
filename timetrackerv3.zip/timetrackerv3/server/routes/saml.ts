
import { Router } from 'express';
import passport from 'passport';
import { samlStrategy, generateSamlMetadata } from '../auth/strategies/saml';

const router = Router();

// Configure SAML strategy
passport.use('saml', samlStrategy);

// SAML metadata endpoint
router.get('/metadata', (req, res) => {
  try {
    const metadata = generateSamlMetadata();
    res.type('application/xml');
    res.send(metadata);
  } catch (error) {
    console.error('🔥 Error generating SAML metadata:', error);
    res.status(500).json({ error: 'Failed to generate metadata' });
  }
});

// SAML SSO initiation (for SP-initiated flow, though you're using IdP-initiated)
router.get('/login', passport.authenticate('saml'));

// SAML callback endpoint (ACS URL)
router.post('/callback', 
  passport.authenticate('saml', { 
    failureRedirect: '/login?error=saml_failed',
    session: true 
  }),
  (req, res) => {
    console.log('🔐 SAML authentication successful for user:', req.user);
    // Redirect to dashboard after successful SAML authentication
    res.redirect('/dashboard');
  }
);

// SAML logout
router.get('/logout', (req, res) => {
  req.logout((err) => {
    if (err) {
      console.error('🔥 SAML logout error:', err);
    }
    res.redirect('/');
  });
});

export default router;
