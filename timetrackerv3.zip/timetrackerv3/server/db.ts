import { drizzle } from 'drizzle-orm/node-sql-server';
import sql from 'mssql';
import * as schema from '@shared/schema';

// SQL Server connection configuration
const sqlServerConfig: sql.config = {
  server: process.env.SQL_SERVER_HOST || 'HUB-SQL1TST-LIS',
  port: parseInt(process.env.SQL_SERVER_PORT || '1433'),
  database: process.env.SQL_SERVER_DATABASE || 'timetracker',
  user: process.env.SQL_SERVER_USER || 'timetracker',
  password: process.env.SQL_SERVER_PASSWORD || 'iTT!$Lo7gm"i\'JAg~5Y\\',
  options: {
    encrypt: process.env.SQL_SERVER_ENCRYPT === 'true',
    trustServerCertificate: process.env.SQL_SERVER_TRUST_CERT === 'true',
    enableArithAbort: true,
    requestTimeout: 30000,
    connectionTimeoutMillis: 30000,
  },
  pool: {
    max: 20,
    min: 0,
    idleTimeoutMillis: 30000
  }
};

// Connection pool and retry logic
let connectionPool: sql.ConnectionPool | null = null;
let isConnecting = false;

export async function getConnectionPool(): Promise<sql.ConnectionPool> {
  if (connectionPool && connectionPool.connected) {
    return connectionPool;
  }

  if (isConnecting) {
    // Wait for existing connection attempt
    while (isConnecting) {
      await new Promise(resolve => setTimeout(resolve, 100));
    }
    if (connectionPool?.connected) {
      return connectionPool;
    }
  }

  isConnecting = true;

  try {
    if (connectionPool) {
      await connectionPool.close();
    }

    connectionPool = new sql.ConnectionPool(sqlServerConfig);
    await connectionPool.connect();

    console.log('✅ Connected to SQL Server successfully');

    // Connection event handlers
    connectionPool.on('error', (err) => {
      console.error('❌ SQL Server connection error:', err);
      connectionPool = null;
    });

    return connectionPool;
  } catch (error) {
    console.error('❌ Failed to connect to SQL Server:', error);
    connectionPool = null;
    throw error;
  } finally {
    isConnecting = false;
  }
}

// Initialize Drizzle with SQL Server
export const db = drizzle(connectionPool!, { schema });

// Database health check function
export async function checkDatabaseHealth(): Promise<boolean> {
  try {
    const pool = await getConnectionPool();
    const result = await pool.request().query('SELECT 1 as health_check');
    return result.recordset[0]?.health_check === 1;
  } catch (error) {
    console.error('❌ Database health check failed:', error);
    return false;
  }
}

// Database retry wrapper
export async function withDatabaseRetry<T>(
  operation: () => Promise<T>,
  maxRetries: number = 3,
  operationName: string = 'Database operation'
): Promise<T> {
  let lastError: Error;

  for (let attempt = 1; attempt <= maxRetries; attempt++) {
    try {
      const pool = await getConnectionPool();
      return await operation();
    } catch (error) {
      lastError = error as Error;
      console.warn(`⚠️ ${operationName} failed (attempt ${attempt}/${maxRetries}):`, error);

      if (attempt < maxRetries) {
        const delay = Math.min(1000 * Math.pow(2, attempt - 1), 5000);
        console.log(`🔄 Retrying in ${delay}ms...`);
        await new Promise(resolve => setTimeout(resolve, delay));

        // Reset connection on retry
        if (connectionPool) {
          try {
            await connectionPool.close();
          } catch {}
          connectionPool = null;
        }
      }
    }
  }

  throw lastError!;
}

// Legacy exports for compatibility
export const pool = {
  query: async (text: string, params?: any[]) => {
    const pool = await getConnectionPool();
    return pool.request().query(text);
  },
  on: (event: string, callback: Function) => {
    // Handle pool events if needed
  }
};