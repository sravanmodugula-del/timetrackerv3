
import { Strategy as SamlStrategy } from 'passport-saml';
import type { Profile, VerifyWithRequest } from 'passport-saml';
import { storage } from '../../storage';

export interface SAMLProfile extends Profile {
  nameID?: string;
  email?: string;
  firstName?: string;
  lastName?: string;
  groups?: string[];
  role?: string;
}

const samlRoleMapping: Record<string, string> = {
  'TimeTracker-Admins': 'admin',
  'TimeTracker-Managers': 'manager', 
  'TimeTracker-ProjectManagers': 'project_manager',
  'TimeTracker-Employees': 'employee'
};

export const samlStrategy = new SamlStrategy({
  callbackUrl: process.env.SAML_CALLBACK_URL!,
  entryPoint: process.env.SAML_ENTRY_POINT!,
  issuer: process.env.SAML_ISSUER!,
  audience: process.env.SAML_AUDIENCE!,
  cert: process.env.SAML_CERT!,
  privateKey: process.env.SAML_PRIVATE_KEY,
  identifierFormat: 'urn:oasis:names:tc:SAML:1.1:nameid-format:emailAddress',
  acceptedClockSkewMs: 30000,
  attributeConsumingServiceIndex: false,
  disableRequestedAuthnContext: true,
  signatureAlgorithm: 'sha256',
  digestAlgorithm: 'sha256'
}, async (profile: SAMLProfile, done: any) => {
  try {
    console.log('🔐 SAML Profile received:', JSON.stringify(profile, null, 2));
    
    const email = profile.email || profile.nameID;
    if (!email) {
      return done(new Error('No email found in SAML profile'));
    }

    const firstName = profile.firstName || profile['http://schemas.xmlsoap.org/ws/2005/05/identity/claims/givenname'] || '';
    const lastName = profile.lastName || profile['http://schemas.xmlsoap.org/ws/2005/05/identity/claims/surname'] || '';
    const name = `${firstName} ${lastName}`.trim() || email;

    // Extract role from SAML attributes
    const samlRoles = profile['http://schemas.microsoft.com/ws/2008/06/identity/claims/role'] || profile.groups || [];
    let role = 'employee'; // default role

    // Map SAML roles to application roles
    for (const samlRole of Array.isArray(samlRoles) ? samlRoles : [samlRoles]) {
      if (samlRoleMapping[samlRole]) {
        role = samlRoleMapping[samlRole];
        break;
      }
    }

    console.log(`🔐 SAML user ${email} mapped to role: ${role}`);

    // Check if user exists
    let user = await storage.getUserByEmail(email);
    
    if (!user) {
      // Create new user with SAML details
      user = await storage.createUser({
        email,
        name,
        role: role as any,
        authSource: 'saml',
        externalId: profile.nameID
      });
      console.log('🔐 Created new SAML user:', user.id);
    } else {
      // Update existing user's last login and role if different
      await storage.updateUserLastLogin(user.id);
      if (user.role !== role) {
        await storage.updateUserRole(user.id, role as any);
        console.log(`🔐 Updated user ${user.id} role to: ${role}`);
      }
    }

    return done(null, user);
  } catch (error) {
    console.error('🔐 SAML authentication error:', error);
    return done(error);
  }
});

export const generateSamlMetadata = () => {
  const metadata = `<?xml version="1.0" encoding="UTF-8"?>
<md:EntityDescriptor xmlns:md="urn:oasis:names:tc:SAML:2.0:metadata" 
                     entityID="${process.env.SAML_ISSUER}">
  <md:SPSSODescriptor AuthnRequestsSigned="false" 
                      WantAssertionsSigned="true" 
                      protocolSupportEnumeration="urn:oasis:names:tc:SAML:2.0:protocol">
    <md:NameIDFormat>urn:oasis:names:tc:SAML:1.1:nameid-format:emailAddress</md:NameIDFormat>
    <md:AssertionConsumerService Binding="urn:oasis:names:tc:SAML:2.0:bindings:HTTP-POST" 
                                 Location="${process.env.SAML_CALLBACK_URL}" 
                                 index="1"/>
  </md:SPSSODescriptor>
</md:EntityDescriptor>`;
  return metadata;
};
