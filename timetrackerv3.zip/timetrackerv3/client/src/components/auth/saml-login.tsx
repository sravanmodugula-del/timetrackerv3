
import { Button } from "../ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "../ui/card";

export function SAMLLogin() {
  const handleSAMLLogin = () => {
    // For IdP-initiated flow, users will typically access the app via the IdP
    // But we can provide a link to the SAML login endpoint
    window.location.href = '/auth/saml/login';
  };

  return (
    <Card className="w-full max-w-md">
      <CardHeader>
        <CardTitle className="text-center">Enterprise Login</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <p className="text-sm text-gray-600 text-center">
            Use your corporate credentials to sign in
          </p>
          <Button 
            onClick={handleSAMLLogin}
            className="w-full"
            variant="default"
          >
            Sign in with RSA SAML
          </Button>
          <div className="text-xs text-gray-500 text-center">
            Note: If you were redirected from your corporate portal, 
            you should be automatically signed in.
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
