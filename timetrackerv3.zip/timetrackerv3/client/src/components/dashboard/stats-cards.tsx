import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Clock, Calendar, BarChart3, FolderOpen, TrendingUp, Timer, Activity, Target, CalendarDays } from "lucide-react";

interface DashboardStats {
  todayHours: number;
  weekHours: number;
  monthHours: number;
  activeProjects: number;
}

interface StatsCardsProps {
  stats: DashboardStats;
}

export default function StatsCards({ stats }: StatsCardsProps) {
  const isLoading = false;

  const statCards = [
    {
      title: "Today's Hours",
      value: stats?.todayHours?.toFixed(1) || "0.0",
      icon: Clock,
      color: "text-primary",
      bgColor: "bg-primary bg-opacity-10",
    },
    {
      title: "This Week",
      value: stats?.weekHours?.toFixed(1) || "0.0",
      icon: Calendar,
      color: "text-green-600",
      bgColor: "bg-green-100",
    },
    {
      title: "Active Projects",
      value: stats?.activeProjects?.toString() || "0",
      icon: BarChart3,
      color: "text-orange-600",
      bgColor: "bg-orange-100",
    },
    {
      title: "This Month",
      value: stats?.monthHours?.toFixed(1) || "0.0",
      icon: CalendarDays,
      color: "text-primary",
      bgColor: "bg-primary bg-opacity-10",
    },
  ];

  if (isLoading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {[...Array(4)].map((_, i) => (
          <Card key={i} className="animate-pulse">
            <CardContent className="p-6">
              <div className="flex items-center">
                <div className="w-12 h-12 bg-gray-200 rounded-lg"></div>
                <div className="ml-4 space-y-2">
                  <div className="h-4 w-20 bg-gray-200 rounded"></div>
                  <div className="h-8 w-16 bg-gray-200 rounded"></div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4 sm:gap-6 lg:gap-8">
      {statCards.map((stat, index) => {
        const Icon = stat.icon;
        return (
          <Card
            key={index}
            className="group relative overflow-hidden border-0 shadow-sm hover:shadow-xl hover:shadow-primary/5 transition-all duration-500 hover:-translate-y-2 bg-gradient-to-br from-card/50 via-card to-card/80 backdrop-blur-sm"
          >
            {/* Gradient background effect */}
            <div className={`absolute inset-0 opacity-30 group-hover:opacity-50 transition-opacity duration-500 ${stat.bgColor}`} />

            <CardHeader className="relative flex flex-row items-center justify-between space-y-0 pb-3 pt-6">
              <div className="space-y-1">
                <CardTitle className="text-sm font-medium text-muted-foreground group-hover:text-foreground transition-colors">
                  {stat.title}
                </CardTitle>
                <div className="flex items-center space-x-2">
                  <span className="text-2xl sm:text-3xl font-bold tracking-tight">
                    {stat.value}
                  </span>
                  <div className={`flex items-center text-xs font-medium text-green-600 dark:text-green-400 bg-green-50 dark:bg-green-950/20 px-2 py-1 rounded-full`}>
                    <TrendingUp className="h-3 w-3 mr-1" />
                    {(() => {
                      switch (stat.title) {
                        case "Today's Hours": return "+12%";
                        case "This Week": return "+8%";
                        case "Active Projects": return "+3";
                        case "This Month": return "+15%";
                        default: return "";
                      }
                    })()}
                  </div>
                </div>
              </div>
              <div className={`rounded-2xl p-3 ${stat.bgColor.replace('bg-primary', 'bg-blue-500').replace('bg-opacity-10', 'dark:bg-blue-400/10')} group-hover:scale-110 transition-transform duration-300`}>
                <Icon className={`h-5 w-5 ${stat.color.replace('text-primary', 'text-blue-600').replace('text-green-600', 'text-green-600 dark:text-green-400').replace('text-orange-600', 'text-orange-600 dark:text-orange-400')}`} />
              </div>
            </CardHeader>

            <CardContent className="relative pt-0 pb-6">
              <p className="text-xs text-muted-foreground/80 group-hover:text-muted-foreground transition-colors">
                {(() => {
                  switch (stat.title) {
                    case "Today's Hours": return 'Hours worked today';
                    case "This Week": return 'Hours this week';
                    case "Active Projects": return 'Current projects';
                    case "This Month": return 'Hours this month';
                    default: return '';
                  }
                })()}
              </p>

              {/* Progress indicator */}
              <div className="mt-3 w-full bg-muted/30 rounded-full h-1 overflow-hidden">
                <div
                  className={`h-full bg-gradient-to-r from-primary/60 to-primary transition-all duration-1000 ease-out group-hover:from-primary group-hover:to-primary/80`}
                  style={{
                    width: `${Math.min(100, (parseFloat(stat.value) / 8) * 100)}%`,
                    transform: 'translateX(-100%)',
                    animation: 'slideIn 1s ease-out forwards'
                  }}
                />
              </div>
            </CardContent>

            {/* Hover glow effect */}
            <div className="absolute inset-0 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity duration-500 bg-gradient-to-r from-transparent via-primary/5 to-transparent" />
          </Card>
        );
      })}
    </div>
  );
}

/* Add slide-in animation */
const style = document.createElement('style');
style.textContent = `
  @keyframes slideIn {
    from { transform: translateX(-100%); }
    to { transform: translateX(0); }
  }
`;
document.head.appendChild(style);