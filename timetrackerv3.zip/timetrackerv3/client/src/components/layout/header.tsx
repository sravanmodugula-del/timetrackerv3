import { useAuth } from "@/hooks/useAuth";
import { usePermissions } from "@/hooks/usePermissions";
import { Link, useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Clock, BarChart3, Plus, List, FolderOpen, CheckSquare, Users, Building, FileText, Menu, Bell, Settings, Search } from "lucide-react";
import { cn } from "@/lib/utils";
import UserMenu from "@/components/layout/user-menu";
import type { Organization } from "@shared/schema";

export default function Header() {
  const { user } = useAuth();
  const [location] = useLocation();
  const { canViewReports } = usePermissions();

  // Fetch organizations to display the first one in header
  const { data: organizations = [] } = useQuery<Organization[]>({
    queryKey: ["/api/organizations"],
    retry: false,
  });

  const organizationName = organizations.length > 0 ? organizations[0].name : "TimeTracker Pro";

  const allNavigationItems = [
    { name: "Dashboard", href: "/", icon: BarChart3, current: location === "/" },
    { name: "Projects", href: "/projects", icon: FolderOpen, current: location === "/projects" },
    { name: "Tasks", href: "/tasks", icon: CheckSquare, current: location === "/tasks" },
    { name: "Employees", href: "/employees", icon: Users, current: location === "/employees" },
    { name: "Organizations", href: "/organizations", icon: Building, current: location === "/organizations" },
    { name: "Departments", href: "/departments", icon: Users, current: location === "/departments" },
    { name: "Reports", href: "/reports", icon: FileText, current: location === "/reports", requiresPermission: "canViewReports" },
    { name: "Log Time", href: "/time-entry", icon: Plus, current: location === "/time-entry" },
    { name: "Time Log", href: "/time-log", icon: List, current: location === "/time-log" },
  ];

  // Filter navigation items based on permissions
  const navigation = allNavigationItems.filter(item => {
    if (item.requiresPermission === "canViewReports") {
      return canViewReports;
    }
    return true; // Show all other items
  });



  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/80 backdrop-blur-md supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-16 max-w-screen-2xl items-center justify-between px-4 lg:px-6">
        <div className="flex items-center space-x-4">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => {}} // Placeholder for sidebar toggle
            className="lg:hidden hover:bg-accent/50 transition-colors"
            aria-label="Toggle sidebar"
          >
            <Menu className="h-5 w-5" />
          </Button>

          <div className="flex items-center space-x-3">
            <div className="flex items-center space-x-3">
              <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-primary via-primary/90 to-primary/80 shadow-lg">
                <Clock className="h-5 w-5 text-primary-foreground" />
              </div>
              <div className="hidden sm:block">
                <h1 className="text-xl font-bold bg-gradient-to-r from-primary via-primary/90 to-primary/80 bg-clip-text text-transparent">
                  {organizationName}
                </h1>
                <p className="text-xs text-muted-foreground -mt-1">
                  Modern Time Management
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Navigation for larger screens */}
        <nav className="hidden md:flex flex-1 max-w-md mx-8">
          {navigation.map((item) => {
            const Icon = item.icon;
            return (
              <Link key={item.name} href={item.href}>
                <button
                  className={cn(
                    "inline-flex items-center px-1 py-4 text-sm font-medium border-b-2 transition-colors",
                    item.current
                      ? "text-primary border-primary"
                      : "text-gray-500 border-transparent hover:text-gray-700 hover:border-gray-300"
                  )}
                >
                  <Icon className="w-4 h-4 mr-2" />
                  {item.name}
                </button>
              </Link>
            );
          })}
        </nav>

        <div className="flex items-center space-x-2 sm:space-x-4">
          {/* Quick actions */}
          <div className="hidden sm:flex items-center space-x-2">
            <Button
              variant="ghost"
              size="icon"
              className="relative hover:bg-accent/50 transition-colors rounded-xl"
              aria-label="Notifications"
            >
              <Bell className="h-5 w-5" />
              <span className="absolute -top-1 -right-1 h-3 w-3 rounded-full bg-primary text-[10px] font-medium text-primary-foreground flex items-center justify-center">
                3
              </span>
            </Button>

            <Button
              variant="ghost"
              size="icon"
              className="hover:bg-accent/50 transition-colors rounded-xl"
              aria-label="Settings"
            >
              <Settings className="h-5 w-5" />
            </Button>
          </div>

          {/* Mobile search button */}
          <Button
            variant="ghost"
            size="icon"
            className="md:hidden hover:bg-accent/50 transition-colors rounded-xl"
            aria-label="Search"
          >
            <Search className="h-5 w-5" />
          </Button>

          <div className="h-6 w-px bg-border/50 hidden sm:block" />
          <UserMenu />
        </div>
      </div>

      {/* Mobile Navigation - Collapsible */}
      <div className="md:hidden border-t border-gray-200 dark:border-gray-800">
        <div className="px-4 py-3 space-y-1">
          {navigation.map((item) => {
            const Icon = item.icon;
            return (
              <Link key={item.name} href={item.href}>
                <button
                  className={cn(
                    "w-full text-left px-3 py-2 text-sm font-medium rounded-md transition-colors",
                    item.current
                      ? "text-primary bg-primary bg-opacity-10"
                      : "text-gray-600 hover:text-gray-900 hover:bg-gray-50"
                  )}
                >
                  <Icon className="w-4 h-4 mr-2 inline" />
                  {item.name}
                </button>
              </Link>
            );
          })}
        </div>
      </div>

      {/* Modern gradient border */}
      <div className="absolute bottom-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-border to-transparent" />
    </header>
  );
}