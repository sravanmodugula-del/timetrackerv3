import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { 
  LayoutDashboard, 
  Clock, 
  FolderOpen, 
  CheckSquare, 
  Users, 
  Building, 
  BarChart3, 
  UserCog,
  X,
  ChevronRight,
  Timer,
  Activity,
  Calendar
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useState } from "react";

interface NavigationProps {
  isOpen?: boolean;
  onClose?: () => void;
}

function Navigation({ isOpen = false, onClose }: NavigationProps) {
  const location = useLocation();
  const [hoveredItem, setHoveredItem] = useState<string | null>(null);

  const navItems = [
    { 
      name: "Dashboard", 
      href: "/", 
      icon: LayoutDashboard, 
      color: "text-blue-600 dark:text-blue-400",
      bgColor: "bg-blue-50 dark:bg-blue-950/50",
      description: "Overview & Analytics"
    },
    { 
      name: "Time Entry", 
      href: "/time-entry", 
      icon: Timer, 
      color: "text-green-600 dark:text-green-400",
      bgColor: "bg-green-50 dark:bg-green-950/50",
      description: "Log your time"
    },
    { 
      name: "Time Log", 
      href: "/time-log", 
      icon: Activity, 
      color: "text-purple-600 dark:text-purple-400",
      bgColor: "bg-purple-50 dark:bg-purple-950/50",
      description: "View time entries"
    },
    { 
      name: "Projects", 
      href: "/projects", 
      icon: FolderOpen, 
      color: "text-orange-600 dark:text-orange-400",
      bgColor: "bg-orange-50 dark:bg-orange-950/50",
      description: "Manage projects"
    },
    { 
      name: "Tasks", 
      href: "/tasks", 
      icon: CheckSquare, 
      color: "text-pink-600 dark:text-pink-400",
      bgColor: "bg-pink-50 dark:bg-pink-950/50",
      description: "Task management"
    },
    { 
      name: "Reports", 
      href: "/reports", 
      icon: BarChart3, 
      color: "text-indigo-600 dark:text-indigo-400",
      bgColor: "bg-indigo-50 dark:bg-indigo-950/50",
      description: "Analytics & Reports"
    },
    { 
      name: "Organizations", 
      href: "/organizations", 
      icon: Building, 
      color: "text-teal-600 dark:text-teal-400",
      bgColor: "bg-teal-50 dark:bg-teal-950/50",
      description: "Company structure"
    },
    { 
      name: "Departments", 
      href: "/departments", 
      icon: Users, 
      color: "text-cyan-600 dark:text-cyan-400",
      bgColor: "bg-cyan-50 dark:bg-cyan-950/50",
      description: "Department management"
    },
    { 
      name: "Employees", 
      href: "/employees", 
      icon: Users, 
      color: "text-emerald-600 dark:text-emerald-400",
      bgColor: "bg-emerald-50 dark:bg-emerald-950/50",
      description: "Staff management"
    },
    { 
      name: "User Management", 
      href: "/user-management", 
      icon: UserCog, 
      color: "text-red-600 dark:text-red-400",
      bgColor: "bg-red-50 dark:bg-red-950/50",
      description: "User permissions"
    },
  ];

  const isActive = (path: string) => location.pathname === path;

  return (
    <>
      {/* Modern mobile overlay */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-black/60 backdrop-blur-sm z-40 lg:hidden animate-fade-in"
          onClick={onClose}
        />
      )}

      {/* Modern sidebar */}
      <nav 
        className={cn(
          "fixed left-0 top-0 z-50 h-full w-72 bg-background/80 backdrop-blur-xl border-r border-border/50 transform transition-all duration-300 ease-out lg:translate-x-0 lg:static lg:z-auto shadow-2xl lg:shadow-none",
          isOpen ? "translate-x-0" : "-translate-x-full"
        )}
      >
        {/* Modern header */}
        <div className="flex items-center justify-between p-6 border-b border-border/50 lg:hidden bg-gradient-to-r from-primary/5 via-primary/10 to-primary/5">
          <div className="flex items-center space-x-3">
            <div className="h-8 w-8 rounded-xl bg-gradient-to-br from-primary to-primary/80 flex items-center justify-center">
              <Clock className="h-4 w-4 text-primary-foreground" />
            </div>
            <span className="font-semibold text-lg bg-gradient-to-r from-primary to-primary/80 bg-clip-text text-transparent">
              Menu
            </span>
          </div>
          <Button
            variant="ghost"
            size="icon"
            onClick={onClose}
            className="rounded-xl hover:bg-accent/50 transition-colors"
            aria-label="Close menu"
          >
            <X className="h-5 w-5" />
          </Button>
        </div>

        {/* Navigation items with modern design */}
        <div className="flex flex-col p-4 space-y-1">
          {navItems.map((item, index) => {
            const Icon = item.icon;
            const active = isActive(item.href);
            const hovered = hoveredItem === item.name;

            return (
              <Link
                key={item.name}
                to={item.href}
                onClick={onClose}
                onMouseEnter={() => setHoveredItem(item.name)}
                onMouseLeave={() => setHoveredItem(null)}
                className={cn(
                  "group relative flex items-center space-x-4 px-4 py-3 rounded-2xl text-sm font-medium transition-all duration-300 hover:shadow-lg",
                  active
                    ? "bg-gradient-to-r from-primary/90 via-primary to-primary/90 text-primary-foreground shadow-lg shadow-primary/20 hover:shadow-primary/30"
                    : "text-muted-foreground hover:text-foreground hover:bg-accent/50 hover:-translate-y-0.5"
                )}
              >
                {/* Background effect for non-active items */}
                {!active && (
                  <div className={cn(
                    "absolute inset-0 rounded-2xl opacity-0 group-hover:opacity-100 transition-all duration-300",
                    item.bgColor
                  )} />
                )}

                <div className={cn(
                  "relative flex h-10 w-10 items-center justify-center rounded-xl transition-all duration-300",
                  active 
                    ? "bg-white/20 shadow-lg" 
                    : `${item.bgColor} group-hover:scale-110`
                )}>
                  <Icon className={cn(
                    "h-5 w-5 transition-colors duration-300",
                    active ? "text-primary-foreground" : item.color
                  )} />
                </div>

                <div className="relative flex-1 min-w-0">
                  <div className="flex items-center justify-between">
                    <span className="truncate font-semibold">
                      {item.name}
                    </span>
                    {(active || hovered) && (
                      <ChevronRight className={cn(
                        "h-4 w-4 transition-all duration-300",
                        active ? "text-primary-foreground" : "text-muted-foreground",
                        hovered && "translate-x-1"
                      )} />
                    )}
                  </div>
                  <p className={cn(
                    "text-xs truncate transition-colors duration-300 mt-0.5",
                    active 
                      ? "text-primary-foreground/80" 
                      : "text-muted-foreground/60 group-hover:text-muted-foreground"
                  )}>
                    {item.description}
                  </p>
                </div>

                {/* Active indicator */}
                {active && (
                  <div className="absolute left-0 top-1/2 -translate-y-1/2 w-1 h-8 bg-primary-foreground/30 rounded-full" />
                )}
              </Link>
            );
          })}
        </div>

        {/* Bottom gradient */}
        <div className="absolute bottom-0 left-0 right-0 h-20 bg-gradient-to-t from-background/50 to-transparent pointer-events-none" />
      </nav>
    </>
  );
}

export default Navigation;