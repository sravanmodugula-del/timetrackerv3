import { useEffect, useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { usePermissions } from "@/hooks/usePermissions";
import { useToast } from "@/hooks/use-toast";
import Header from "@/components/layout/header";
import StatsCards from "@/components/dashboard/stats-cards";
import ProjectBreakdown from "@/components/dashboard/project-breakdown";

import DepartmentHours from "@/components/dashboard/department-hours";
import RecentActivity from "@/components/dashboard/recent-activity";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Calendar, TrendingUp, Clock, Plus, Filter, Download, RefreshCw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";

interface DashboardStats {
  todayHours: number;
  weekHours: number;
  monthHours: number;
  activeProjects: number;
}

export default function Dashboard() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading } = useAuth();
  const permissions = usePermissions();
  const [dateRange, setDateRange] = useState<string>("week");
  const [isRefreshing, setIsRefreshing] = useState(false);


  // Calculate date filters
  const getDateFilters = () => {
    const now = new Date();
    const todayPST = now.toLocaleDateString('en-CA', { timeZone: 'America/Los_Angeles' });
    const today = new Date(todayPST + 'T00:00:00');

    switch (dateRange) {
      case "today":
        return {
          startDate: todayPST,
          endDate: todayPST,
        };
      case "week": {
        const startDate = new Date(today);
        startDate.setDate(today.getDate() - 7);
        return {
          startDate: startDate.toLocaleDateString('en-CA', { timeZone: 'America/Los_Angeles' }),
          endDate: todayPST,
        };
      }
      case "month": {
        const startDate = new Date(today);
        startDate.setMonth(today.getMonth() - 1);
        return {
          startDate: startDate.toLocaleDateString('en-CA', { timeZone: 'America/Los_Angeles' }),
          endDate: todayPST,
        };
      }
      case "quarter": {
        const startDate = new Date(today);
        startDate.setMonth(today.getMonth() - 3);
        return {
          startDate: startDate.toLocaleDateString('en-CA', { timeZone: 'America/Los_Angeles' }),
          endDate: todayPST,
        };
      }
      case "year": {
        const startDate = new Date(today);
        startDate.setFullYear(today.getFullYear() - 1);
        return {
          startDate: startDate.toLocaleDateString('en-CA', { timeZone: 'America/Los_Angeles' }),
          endDate: todayPST,
        };
      }
      default: {
        const startDate = new Date(today);
        startDate.setDate(today.getDate() - 7);
        return {
          startDate: startDate.toLocaleDateString('en-CA', { timeZone: 'America/Los_Angeles' }),
          endDate: todayPST,
        };
      }
    }
  };

  const { data: stats, isLoading: statsLoading, refetch: refetchStats } = useQuery<DashboardStats>({
    queryKey: ["dashboard", "stats", dateRange],
    queryFn: async () => {
      const { startDate, endDate } = getDateFilters();
      const params = new URLSearchParams({ startDate, endDate });
      const response = await fetch(`/api/dashboard/stats?${params}`);
      if (!response.ok) {
        throw new Error("Failed to fetch dashboard stats");
      }
      return response.json();
    },
  });

  const { data: recentActivity, isLoading: activityLoading, refetch: refetchActivity } = useQuery({
    queryKey: ["dashboard", "recent-activity", dateRange],
    queryFn: async () => {
      const { startDate, endDate } = getDateFilters();
      const params = new URLSearchParams({ startDate, endDate, limit: "10" });
      const response = await fetch(`/api/dashboard/recent-activity?${params}`);
      if (!response.ok) {
        throw new Error("Failed to fetch recent activity");
      }
      return response.json();
    },
  });

  const { data: projectBreakdown, isLoading: projectsLoading, refetch: refetchProjects } = useQuery({
    queryKey: ["dashboard", "project-breakdown", dateRange],
    queryFn: async () => {
      const { startDate, endDate } = getDateFilters();
      const params = new URLSearchParams({ startDate, endDate });
      const response = await fetch(`/api/dashboard/project-breakdown?${params}`);
      if (!response.ok) {
        throw new Error("Failed to fetch project breakdown");
      }
      return response.json();
    },
  });

  const handleRefresh = async () => {
    setIsRefreshing(true);
    try {
      await Promise.all([
        refetchStats(),
        refetchActivity(),
        refetchProjects()
      ]);
    } finally {
      setIsRefreshing(false);
    }
  };

  // Redirect to home if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-background via-background/95 to-primary/5">
        <div className="container mx-auto space-y-8 p-6 animate-fade-in">
          <div className="flex flex-col space-y-4 animate-pulse">
            <div className="h-12 bg-gradient-to-r from-muted via-muted/50 to-muted rounded-2xl w-1/3"></div>
            <div className="h-6 bg-gradient-to-r from-muted/60 via-muted/30 to-muted/60 rounded-xl w-1/2"></div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-6 animate-pulse">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="h-40 bg-gradient-to-br from-muted via-muted/50 to-muted rounded-3xl shadow-sm"></div>
            ))}
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 animate-pulse">
            <div className="h-80 bg-gradient-to-br from-muted via-muted/50 to-muted rounded-3xl shadow-sm"></div>
            <div className="h-80 bg-gradient-to-br from-muted via-muted/50 to-muted rounded-3xl shadow-sm"></div>
          </div>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return null; // Or a minimal login prompt if needed, but redirect handles this.
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background/95 to-primary/5">
      <Header />
      <div className="container mx-auto space-y-8 p-6 animate-fade-in max-w-screen-2xl">
        {/* Modern header section */}
        <div className="flex flex-col space-y-4 sm:space-y-0 sm:flex-row sm:items-center sm:justify-between">
          <div className="space-y-2">
            <h1 className="text-4xl sm:text-5xl font-bold tracking-tight bg-gradient-to-r from-primary via-primary/90 to-primary/80 bg-clip-text text-transparent">
              Dashboard
            </h1>
            <p className="text-lg text-muted-foreground max-w-md">
              Track your productivity and manage your time efficiently with real-time insights.
            </p>
          </div>

          {/* Action buttons */}
          <div className="flex flex-wrap items-center gap-3">
            <Button
              variant="outline"
              size="sm"
              className="rounded-xl"
              onClick={handleRefresh}
              disabled={isRefreshing}
            >
              <RefreshCw className={`h-4 w-4 mr-2 ${isRefreshing ? 'animate-spin' : ''}`} />
              Refresh
            </Button>

            <Card className="w-auto h-10">
              <CardContent className="p-2">
                <div className="flex items-center gap-2">
                  <Calendar className="h-4 w-4 text-muted-foreground" />
                  <Select value={dateRange} onValueChange={setDateRange}>
                    <SelectTrigger className="w-36">
                      <SelectValue placeholder="Select period" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="today">Today</SelectItem>
                      <SelectItem value="week">Last 7 days</SelectItem>
                      <SelectItem value="month">Last 30 days</SelectItem>
                      <SelectItem value="quarter">Last 3 months</SelectItem>
                      <SelectItem value="year">Last 12 months</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </CardContent>
            </Card>

            <Button
              variant="outline"
              size="sm"
              className="rounded-xl"
            >
              <Filter className="h-4 w-4 mr-2" />
              Filters
            </Button>

            <Button
              size="sm"
              className="rounded-xl btn-gradient"
            >
              <Plus className="h-4 w-4 mr-2" />
              New Entry
            </Button>
          </div>
        </div>

        {/* Enhanced stats cards */}
        {statsLoading ? (
          <div className="animate-pulse grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-6">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="h-40 bg-gradient-to-br from-muted via-muted/50 to-muted rounded-3xl shadow-sm"></div>
            ))}
          </div>
        ) : (
          <StatsCards stats={stats || {
            todayHours: 0,
            weekHours: 0,
            monthHours: 0,
            totalProjects: 0,
            activeProjects: 0,
            completedTasks: 0,
            pendingTasks: 0,
            totalTasks: 0
          }} />
        )}


        {/* Modern charts grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Recent Activity Card */}
          <Card className="card-modern border-0 overflow-hidden">
            <CardHeader className="bg-gradient-to-br from-card via-card/95 to-accent/20 border-b border-border/50">
              <div className="flex items-center justify-between">
                <div className="space-y-1">
                  <CardTitle className="text-xl font-semibold flex items-center space-x-2">
                    <TrendingUp className="h-5 w-5 text-primary" />
                    <span>Recent Activity</span>
                  </CardTitle>
                  <p className="text-sm text-muted-foreground">
                    Your latest time entries and progress
                  </p>
                </div>
                <Button variant="ghost" size="sm" className="rounded-xl">
                  <Download className="h-4 w-4" />
                </Button>
              </div>
            </CardHeader>
            <CardContent className="p-6">
              {activityLoading ? (
                <div className="animate-pulse h-64 bg-gradient-to-br from-muted via-muted/50 to-muted rounded-3xl shadow-sm"></div>
              ) : (
                <RecentActivity data={recentActivity || []} />
              )}
            </CardContent>
          </Card>

          {/* Project Breakdown Card */}
          <Card className="card-modern border-0 overflow-hidden">
            <CardHeader className="bg-gradient-to-br from-card via-card/95 to-accent/20 border-b border-border/50">
              <div className="flex items-center justify-between">
                <div className="space-y-1">
                  <CardTitle className="text-xl font-semibold flex items-center space-x-2">
                    <TrendingUp className="h-5 w-5 text-primary" />
                    <span>Project Analytics</span>
                  </CardTitle>
                  <p className="text-sm text-muted-foreground">
                    Time distribution across your projects
                  </p>
                </div>
                <Button variant="ghost" size="sm" className="rounded-xl">
                  <Download className="h-4 w-4" />
                </Button>
              </div>
            </CardHeader>
            <CardContent className="p-6">
              {projectsLoading ? (
                <div className="animate-pulse h-64 bg-gradient-to-br from-muted via-muted/50 to-muted rounded-3xl shadow-sm"></div>
              ) : (
                <ProjectBreakdown data={projectBreakdown || []} />
              )}
            </CardContent>
          </Card>
        </div>

        {/* Department Hours - Enhanced for managers and admins */}
        {permissions.canViewDepartmentData && (
          <Card className="card-modern border-0 overflow-hidden">
            <CardHeader className="bg-gradient-to-br from-card via-card/95 to-accent/20 border-b border-border/50">
              <div className="flex flex-col space-y-4 sm:space-y-0 sm:flex-row sm:items-center sm:justify-between">
                <div className="space-y-1">
                  <CardTitle className="text-xl font-semibold flex items-center space-x-2">
                    <TrendingUp className="h-5 w-5 text-primary" />
                    <span>Department Analytics</span>
                  </CardTitle>
                  <p className="text-sm text-muted-foreground">
                    Team performance and hours worked across departments
                  </p>
                </div>
                <div className="flex items-center space-x-2">
                  <Button variant="outline" size="sm" className="rounded-xl">
                    Export Report
                  </Button>
                  <Button variant="ghost" size="sm" className="rounded-xl">
                    <Download className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent className="p-6">
              <DepartmentHours />
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}